import westpy 
westpy.plot_2dslice('wfc.cube','band2.png',[400,300],0,0.1,True)
#westpy.plot_species_abundancy('rho.cube','rho.png')
#westpy.plot_dos('energy.dat','dos.png',[3.,11.,0.01])
#westpy.plot_ldos('energy_KS.dat','dos_KS.png',[3.7,10.5,0.1])
#westpy.plot_ldos('energy_QP.dat','dos_QP.png',[3.5,10.5,0.1])
#westpy.plot_ldos('energy_NP3.dat','dos_QP.png',[-7,0,0.05])
